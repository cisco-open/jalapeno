static const char SNAPSHOT[] = "180402";
